import { Link, useLocation } from "wouter";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MobileLayoutProps {
  children: React.ReactNode;
  title?: string;
  showBackButton?: boolean;
}

export function MobileLayout({ children, title, showBackButton = true }: MobileLayoutProps) {
  const [location, setLocation] = useLocation();

  const handleBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      setLocation("/mobile/dashboard");
    }
  };

  return (
    <div className="fixed inset-0 flex flex-col bg-background">
      <header className="flex-shrink-0 flex items-center gap-2 px-2 py-3 bg-gradient-to-r from-teal-500 to-cyan-500 safe-area-top">
        {showBackButton && (
          <Button
            variant="ghost"
            size="icon"
            onClick={handleBack}
            className="text-white hover:bg-white/20"
            data-testid="button-back"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
        )}
        <h1 className="text-white text-lg font-semibold flex-1">
          {title || "BuildPlus"}
        </h1>
      </header>
      
      <main 
        className="flex-1 overflow-y-auto overscroll-contain pb-6"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
        {children}
      </main>
    </div>
  );
}
