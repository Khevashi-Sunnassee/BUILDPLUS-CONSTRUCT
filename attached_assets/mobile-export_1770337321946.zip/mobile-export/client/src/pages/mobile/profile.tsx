import { useAuth } from "@/lib/auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  User, 
  Mail, 
  Shield, 
  LogOut, 
  Moon,
  Sun,
  ChevronLeft,
} from "lucide-react";
import { useTheme } from "@/lib/theme";
import { Link } from "wouter";
import MobileBottomNav from "@/components/mobile/MobileBottomNav";

export default function MobileProfilePage() {
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();

  const getInitials = (name: string | null | undefined, email: string | undefined): string => {
    if (name) {
      return name
        .split(" ")
        .map(n => n[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);
    }
    return email?.charAt(0).toUpperCase() || "U";
  };

  const themeOptions: Array<{ value: "light" | "dark"; label: string; icon: typeof Sun }> = [
    { value: "light", label: "Light", icon: Sun },
    { value: "dark", label: "Dark", icon: Moon },
  ];

  return (
    <div className="flex flex-col h-screen bg-[#070B12] text-white overflow-hidden">
      <div className="flex-shrink-0 border-b border-white/10 bg-[#070B12]/95 backdrop-blur z-10" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
        <div className="flex items-center gap-2 px-4 py-4">
          <Link href="/mobile/more">
            <Button variant="ghost" size="icon" className="text-white -ml-2">
              <ChevronLeft className="h-6 w-6" />
            </Button>
          </Link>
          <div className="text-2xl font-bold">Profile</div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-24 pt-6">
        <div className="flex flex-col items-center mb-8">
          <Avatar className="h-20 w-20 mb-3">
            <AvatarFallback className="bg-purple-500/20 text-purple-400 text-2xl">
              {getInitials(user?.name, user?.email)}
            </AvatarFallback>
          </Avatar>
          <h1 className="text-xl font-bold text-white" data-testid="text-profile-name">
            {user?.name || "User"}
          </h1>
          <p className="text-sm text-white/60">{user?.email}</p>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 overflow-hidden mb-4">
          <div className="divide-y divide-white/10">
            <div className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <User className="h-5 w-5 text-blue-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-white/60">Name</p>
                <p className="font-medium text-white">{user?.name || "Not set"}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                <Mail className="h-5 w-5 text-green-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-white/60">Email</p>
                <p className="font-medium text-white">{user?.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <Shield className="h-5 w-5 text-purple-400" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-white/60">Role</p>
                <p className="font-medium capitalize text-white">{user?.role?.toLowerCase() || "User"}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-4 mb-4">
          <h3 className="text-sm font-semibold mb-3 text-white">Appearance</h3>
          <div className="flex gap-2">
            {themeOptions.map((option) => {
              const Icon = option.icon;
              const isActive = theme === option.value;
              
              return (
                <Button
                  key={option.value}
                  variant={isActive ? "default" : "outline"}
                  onClick={() => setTheme(option.value)}
                  className={`flex-1 flex flex-col items-center gap-1 h-auto py-3 ${
                    isActive ? "bg-purple-500" : "border-white/20 text-white"
                  }`}
                  data-testid={`theme-${option.value}`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-xs">{option.label}</span>
                </Button>
              );
            })}
          </div>
        </div>

        <Button 
          variant="destructive" 
          className="w-full"
          onClick={() => logout()}
          data-testid="button-logout"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>

      <MobileBottomNav />
    </div>
  );
}
