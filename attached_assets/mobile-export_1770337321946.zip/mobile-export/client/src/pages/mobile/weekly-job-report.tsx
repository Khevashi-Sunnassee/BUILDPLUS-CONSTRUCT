import { useState } from "react";
import { MobileLayout } from "@/components/layout/mobile-layout";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { WEEKLY_REPORTS_ROUTES, JOBS_ROUTES } from "@shared/api-routes";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, parseISO, addDays, getDay } from "date-fns";
import { FileText, Send, Check, X, Plus, ChevronRight, Calendar, Building2, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

interface Job {
  id: string;
  jobNumber: string;
  name: string;
  status: string;
}

interface ScheduleItem {
  id?: string;
  jobId: string;
  priority: number;
  levels7Days: string;
  levels14Days: string;
  levels21Days: string;
  levels28Days: string;
  siteProgress: string | null;
  currentLevelOnsite: string | null;
  scheduleStatus: string;
  job?: Job;
}

interface User {
  id: string;
  name: string | null;
  email: string;
}

interface WeeklyJobReport {
  id: string;
  reportDate: string;
  weekStartDate: string;
  weekEndDate: string;
  status: string;
  notes: string | null;
  projectManagerId: string;
  projectManager?: User;
  schedules: ScheduleItem[];
  submittedAt?: string;
  approvedAt?: string;
  approvedBy?: User;
  rejectionReason?: string | null;
}

const statusConfig: Record<string, { label: string; color: string }> = {
  DRAFT: { label: "Draft", color: "bg-slate-500/10 text-slate-500" },
  SUBMITTED: { label: "Submitted", color: "bg-blue-500/10 text-blue-500" },
  APPROVED: { label: "Approved", color: "bg-green-500/10 text-green-500" },
  REJECTED: { label: "Rejected", color: "bg-red-500/10 text-red-500" },
};

const scheduleStatusOptions = [
  { value: "ON_TRACK", label: "On Track" },
  { value: "AT_RISK", label: "At Risk" },
  { value: "DELAYED", label: "Delayed" },
  { value: "AHEAD", label: "Ahead" },
];

export default function MobileWeeklyJobReportPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const isManagerOrAdmin = user?.role === "MANAGER" || user?.role === "ADMIN";
  
  const [selectedReport, setSelectedReport] = useState<WeeklyJobReport | null>(null);
  const [showCreateSheet, setShowCreateSheet] = useState(false);
  const [showViewSheet, setShowViewSheet] = useState(false);
  const [showApprovalSheet, setShowApprovalSheet] = useState(false);
  
  const [reportDate, setReportDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [weekStartDate, setWeekStartDate] = useState("");
  const [weekEndDate, setWeekEndDate] = useState("");
  const [generalNotes, setGeneralNotes] = useState("");
  const [schedules, setSchedules] = useState<ScheduleItem[]>([]);
  const [rejectionReason, setRejectionReason] = useState("");

  const { data: myReports = [], isLoading: loadingMy } = useQuery<WeeklyJobReport[]>({
    queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_MY],
  });

  const { data: pendingReports = [], isLoading: loadingPending } = useQuery<WeeklyJobReport[]>({
    queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_PENDING],
    enabled: isManagerOrAdmin,
  });

  const { data: allJobs = [] } = useQuery<Job[]>({
    queryKey: [JOBS_ROUTES.LIST],
  });

  const activeJobs = allJobs.filter(j => j.status === "ACTIVE");

  const calculateWeekBoundaries = (dateStr: string) => {
    if (!dateStr) return { weekStart: "", weekEnd: "" };
    const date = parseISO(dateStr);
    const currentDay = getDay(date);
    const weekStartDay = 1;
    const daysToSubtract = (currentDay - weekStartDay + 7) % 7;
    const weekStart = addDays(date, -daysToSubtract);
    const weekEnd = addDays(weekStart, 6);
    return {
      weekStart: format(weekStart, "yyyy-MM-dd"),
      weekEnd: format(weekEnd, "yyyy-MM-dd"),
    };
  };

  const createMutation = useMutation({
    mutationFn: async (data: { reportDate: string; weekStartDate: string; weekEndDate: string; notes: string; schedules: ScheduleItem[] }) => {
      const response = await apiRequest("POST", WEEKLY_REPORTS_ROUTES.JOB_REPORTS, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_MY] });
      toast({ title: "Report created" });
      resetForm();
    },
    onError: () => {
      toast({ title: "Failed to create report", variant: "destructive" });
    },
  });

  const submitMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("POST", WEEKLY_REPORTS_ROUTES.JOB_REPORT_SUBMIT(id), {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_MY] });
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_PENDING] });
      toast({ title: "Report submitted for approval" });
      setShowViewSheet(false);
      setSelectedReport(null);
    },
    onError: () => {
      toast({ title: "Failed to submit", variant: "destructive" });
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("POST", WEEKLY_REPORTS_ROUTES.JOB_REPORT_APPROVE(id), {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_MY] });
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_PENDING] });
      toast({ title: "Report approved" });
      setShowApprovalSheet(false);
      setSelectedReport(null);
    },
    onError: () => {
      toast({ title: "Failed to approve", variant: "destructive" });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      return apiRequest("POST", WEEKLY_REPORTS_ROUTES.JOB_REPORT_REJECT(id), { rejectionReason: reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_MY] });
      queryClient.invalidateQueries({ queryKey: [WEEKLY_REPORTS_ROUTES.JOB_REPORTS_PENDING] });
      toast({ title: "Report rejected" });
      setShowApprovalSheet(false);
      setSelectedReport(null);
      setRejectionReason("");
    },
    onError: () => {
      toast({ title: "Failed to reject", variant: "destructive" });
    },
  });

  const resetForm = () => {
    setShowCreateSheet(false);
    setReportDate(format(new Date(), "yyyy-MM-dd"));
    setWeekStartDate("");
    setWeekEndDate("");
    setGeneralNotes("");
    setSchedules([]);
  };

  const openCreateSheet = () => {
    const { weekStart, weekEnd } = calculateWeekBoundaries(reportDate);
    setWeekStartDate(weekStart);
    setWeekEndDate(weekEnd);
    setShowCreateSheet(true);
  };

  const addSchedule = () => {
    setSchedules([...schedules, {
      jobId: "",
      priority: schedules.length + 1,
      levels7Days: "",
      levels14Days: "",
      levels21Days: "",
      levels28Days: "",
      siteProgress: null,
      currentLevelOnsite: null,
      scheduleStatus: "ON_TRACK",
    }]);
  };

  const updateSchedule = (index: number, field: keyof ScheduleItem, value: string | number | null) => {
    const updated = [...schedules];
    updated[index] = { ...updated[index], [field]: value };
    setSchedules(updated);
  };

  const removeSchedule = (index: number) => {
    setSchedules(schedules.filter((_, i) => i !== index));
  };

  const handleCreate = () => {
    if (!weekStartDate || !weekEndDate) {
      toast({ title: "Please set week dates", variant: "destructive" });
      return;
    }
    createMutation.mutate({
      reportDate,
      weekStartDate,
      weekEndDate,
      notes: generalNotes,
      schedules: schedules.filter(s => s.jobId),
    });
  };

  const formatDateShort = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), "dd MMM");
    } catch {
      return dateStr;
    }
  };

  const formatDateFull = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), "dd MMM yyyy");
    } catch {
      return dateStr;
    }
  };

  const draftReports = myReports.filter(r => r.status === "DRAFT");
  const submittedReports = myReports.filter(r => r.status === "SUBMITTED");
  const completedReports = myReports.filter(r => ["APPROVED", "REJECTED"].includes(r.status)).slice(0, 5);

  return (
    <MobileLayout title="Weekly Report">
      <div className="px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-bold" data-testid="text-report-title">Weekly Job Reports</h1>
            <p className="text-sm text-muted-foreground">
              {isManagerOrAdmin && pendingReports.length > 0 
                ? `${pendingReports.length} pending approval`
                : `${myReports.length} report${myReports.length !== 1 ? 's' : ''}`
              }
            </p>
          </div>
          <Button size="sm" onClick={openCreateSheet} data-testid="button-new-report">
            <Plus className="h-4 w-4 mr-1" />
            New
          </Button>
        </div>

        {loadingMy || loadingPending ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 rounded-xl" />)}
          </div>
        ) : (
          <div className="space-y-4">
            {isManagerOrAdmin && pendingReports.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  Pending Approval ({pendingReports.length})
                </h2>
                <div className="space-y-3">
                  {pendingReports.map(report => (
                    <ReportCard 
                      key={report.id} 
                      report={report} 
                      onSelect={() => {
                        setSelectedReport(report);
                        setShowApprovalSheet(true);
                      }}
                      showPM
                    />
                  ))}
                </div>
              </div>
            )}

            {draftReports.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  Drafts ({draftReports.length})
                </h2>
                <div className="space-y-3">
                  {draftReports.map(report => (
                    <ReportCard 
                      key={report.id} 
                      report={report} 
                      onSelect={() => {
                        setSelectedReport(report);
                        setShowViewSheet(true);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {submittedReports.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  Submitted ({submittedReports.length})
                </h2>
                <div className="space-y-3">
                  {submittedReports.map(report => (
                    <ReportCard 
                      key={report.id} 
                      report={report} 
                      onSelect={() => {
                        setSelectedReport(report);
                        setShowViewSheet(true);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}

            {completedReports.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  Recent History
                </h2>
                <div className="space-y-3">
                  {completedReports.map(report => (
                    <ReportCard 
                      key={report.id} 
                      report={report} 
                      onSelect={() => {
                        setSelectedReport(report);
                        setShowViewSheet(true);
                      }}
                      muted
                    />
                  ))}
                </div>
              </div>
            )}

            {myReports.length === 0 && pendingReports.length === 0 && (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
                <p className="text-muted-foreground">No reports yet</p>
                <p className="text-sm text-muted-foreground/70">Create your first weekly report</p>
              </div>
            )}
          </div>
        )}
      </div>

      <Sheet open={showCreateSheet} onOpenChange={setShowCreateSheet}>
        <SheetContent side="bottom" className="h-[85vh] rounded-t-2xl overflow-hidden">
          <SheetHeader className="pb-4">
            <SheetTitle>New Weekly Report</SheetTitle>
          </SheetHeader>
          <div className="flex-1 overflow-auto space-y-4 pb-20">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm">Report Date</Label>
                <Input
                  type="date"
                  value={reportDate}
                  onChange={(e) => {
                    setReportDate(e.target.value);
                    const { weekStart, weekEnd } = calculateWeekBoundaries(e.target.value);
                    setWeekStartDate(weekStart);
                    setWeekEndDate(weekEnd);
                  }}
                  data-testid="input-report-date"
                />
              </div>
              <div>
                <Label className="text-sm">Week Start</Label>
                <Input
                  type="date"
                  value={weekStartDate}
                  onChange={(e) => {
                    const { weekStart, weekEnd } = calculateWeekBoundaries(e.target.value);
                    setWeekStartDate(weekStart);
                    setWeekEndDate(weekEnd);
                  }}
                  data-testid="input-week-start"
                />
              </div>
            </div>

            {weekStartDate && weekEndDate && (
              <div className="p-3 bg-muted/50 rounded-lg">
                <p className="text-sm">
                  <Calendar className="h-4 w-4 inline mr-2" />
                  Week: {formatDateFull(weekStartDate)} - {formatDateFull(weekEndDate)}
                </p>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-sm">Job Schedules</Label>
                <Button size="sm" variant="outline" onClick={addSchedule} data-testid="button-add-job">
                  <Plus className="h-4 w-4 mr-1" />
                  Add Job
                </Button>
              </div>
              
              {schedules.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Add jobs to include in this report
                </p>
              ) : (
                <div className="space-y-3">
                  {schedules.map((schedule, index) => (
                    <div key={index} className="p-3 bg-card border rounded-lg space-y-3">
                      <div className="flex items-center gap-2">
                        <Select
                          value={schedule.jobId}
                          onValueChange={(value) => updateSchedule(index, "jobId", value)}
                        >
                          <SelectTrigger className="flex-1" data-testid={`select-job-${index}`}>
                            <SelectValue placeholder="Select job" />
                          </SelectTrigger>
                          <SelectContent>
                            {activeJobs.map(job => (
                              <SelectItem key={job.id} value={job.id}>
                                {job.jobNumber} - {job.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button 
                          size="icon" 
                          variant="ghost"
                          onClick={() => removeSchedule(index)}
                          data-testid={`button-remove-${index}`}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">7 Day Levels</Label>
                          <Input
                            placeholder="e.g. L1, L2"
                            value={schedule.levels7Days}
                            onChange={(e) => updateSchedule(index, "levels7Days", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">14 Day Levels</Label>
                          <Input
                            placeholder="e.g. L3, L4"
                            value={schedule.levels14Days}
                            onChange={(e) => updateSchedule(index, "levels14Days", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">21 Day Levels</Label>
                          <Input
                            placeholder="e.g. L5"
                            value={schedule.levels21Days}
                            onChange={(e) => updateSchedule(index, "levels21Days", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">28 Day Levels</Label>
                          <Input
                            placeholder="e.g. L6"
                            value={schedule.levels28Days}
                            onChange={(e) => updateSchedule(index, "levels28Days", e.target.value)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Current Level Onsite</Label>
                          <Input
                            placeholder="e.g. L2"
                            value={schedule.currentLevelOnsite || ""}
                            onChange={(e) => updateSchedule(index, "currentLevelOnsite", e.target.value || null)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Status</Label>
                          <Select
                            value={schedule.scheduleStatus}
                            onValueChange={(value) => updateSchedule(index, "scheduleStatus", value)}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {scheduleStatusOptions.map(opt => (
                                <SelectItem key={opt.value} value={opt.value}>
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label className="text-xs">Site Progress</Label>
                        <Textarea
                          placeholder="Notes on site progress..."
                          value={schedule.siteProgress || ""}
                          onChange={(e) => updateSchedule(index, "siteProgress", e.target.value || null)}
                          className="min-h-[60px]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <Label className="text-sm">General Notes</Label>
              <Textarea
                placeholder="Overall notes for this week..."
                value={generalNotes}
                onChange={(e) => setGeneralNotes(e.target.value)}
                className="min-h-[80px]"
                data-testid="input-notes"
              />
            </div>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 bg-background border-t">
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={resetForm}>
                Cancel
              </Button>
              <Button 
                className="flex-1"
                onClick={handleCreate}
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? "Creating..." : "Create Draft"}
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <Sheet open={showViewSheet} onOpenChange={(open) => !open && setShowViewSheet(false)}>
        <SheetContent side="bottom" className="h-[80vh] rounded-t-2xl">
          {selectedReport && (
            <ReportViewSheet
              report={selectedReport}
              onClose={() => {
                setShowViewSheet(false);
                setSelectedReport(null);
              }}
              onSubmit={() => submitMutation.mutate(selectedReport.id)}
              isSubmitting={submitMutation.isPending}
              canSubmit={selectedReport.status === "DRAFT" && selectedReport.projectManagerId === user?.id}
            />
          )}
        </SheetContent>
      </Sheet>

      <Sheet open={showApprovalSheet} onOpenChange={(open) => !open && setShowApprovalSheet(false)}>
        <SheetContent side="bottom" className="h-[80vh] rounded-t-2xl">
          {selectedReport && (
            <ReportApprovalSheet
              report={selectedReport}
              onClose={() => {
                setShowApprovalSheet(false);
                setSelectedReport(null);
                setRejectionReason("");
              }}
              onApprove={() => approveMutation.mutate(selectedReport.id)}
              onReject={() => rejectMutation.mutate({ id: selectedReport.id, reason: rejectionReason })}
              isApproving={approveMutation.isPending}
              isRejecting={rejectMutation.isPending}
              rejectionReason={rejectionReason}
              setRejectionReason={setRejectionReason}
            />
          )}
        </SheetContent>
      </Sheet>
    </MobileLayout>
  );
}

function ReportCard({ 
  report, 
  onSelect, 
  muted = false,
  showPM = false 
}: { 
  report: WeeklyJobReport; 
  onSelect: () => void; 
  muted?: boolean;
  showPM?: boolean;
}) {
  const status = statusConfig[report.status] || statusConfig.DRAFT;

  const formatDateShort = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), "dd MMM");
    } catch {
      return dateStr;
    }
  };

  return (
    <button
      onClick={onSelect}
      className={cn(
        "w-full p-4 rounded-xl border border-border hover-elevate active-elevate-2 text-left",
        muted ? "bg-card/50" : "bg-card"
      )}
      data-testid={`report-${report.id}`}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm">
            Week of {formatDateShort(report.weekStartDate)}
          </h3>
          {showPM && report.projectManager && (
            <p className="text-xs text-muted-foreground truncate">
              {report.projectManager.name || report.projectManager.email}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <Badge variant="secondary" className={cn("text-xs", status.color)}>
            {status.label}
          </Badge>
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
      
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <Building2 className="h-3.5 w-3.5" />
          {report.schedules?.length || 0} job{(report.schedules?.length || 0) !== 1 ? 's' : ''}
        </span>
        <span className="flex items-center gap-1">
          <Calendar className="h-3.5 w-3.5" />
          {formatDateShort(report.reportDate)}
        </span>
      </div>
    </button>
  );
}

function ReportViewSheet({
  report,
  onClose,
  onSubmit,
  isSubmitting,
  canSubmit,
}: {
  report: WeeklyJobReport;
  onClose: () => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  canSubmit: boolean;
}) {
  const status = statusConfig[report.status] || statusConfig.DRAFT;

  const formatDateFull = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), "dd MMM yyyy");
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <SheetHeader className="pb-4">
        <div className="flex items-center gap-2">
          <SheetTitle className="text-left flex-1">Week of {formatDateFull(report.weekStartDate)}</SheetTitle>
          <Badge variant="secondary" className={cn("text-xs", status.color)}>
            {status.label}
          </Badge>
        </div>
      </SheetHeader>

      <div className="flex-1 overflow-auto space-y-4">
        <div className="p-3 bg-muted/50 rounded-lg">
          <p className="text-sm">
            <Calendar className="h-4 w-4 inline mr-2" />
            {formatDateFull(report.weekStartDate)} - {formatDateFull(report.weekEndDate)}
          </p>
        </div>

        {report.schedules && report.schedules.length > 0 && (
          <div>
            <Label className="text-sm font-medium mb-2 block">
              Jobs ({report.schedules.length})
            </Label>
            <div className="space-y-2">
              {report.schedules.map((schedule) => (
                <div key={schedule.id} className="p-3 bg-card border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">
                      {schedule.job?.jobNumber} - {schedule.job?.name || "Unknown Job"}
                    </h4>
                    <Badge variant="outline" className="text-xs">
                      {schedule.scheduleStatus?.replace("_", " ")}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                    {schedule.levels7Days && (
                      <p>7 Day: {schedule.levels7Days}</p>
                    )}
                    {schedule.levels14Days && (
                      <p>14 Day: {schedule.levels14Days}</p>
                    )}
                    {schedule.levels21Days && (
                      <p>21 Day: {schedule.levels21Days}</p>
                    )}
                    {schedule.levels28Days && (
                      <p>28 Day: {schedule.levels28Days}</p>
                    )}
                  </div>
                  {schedule.currentLevelOnsite && (
                    <p className="text-xs mt-2">
                      Currently onsite: {schedule.currentLevelOnsite}
                    </p>
                  )}
                  {schedule.siteProgress && (
                    <p className="text-xs text-muted-foreground mt-2">
                      {schedule.siteProgress}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {report.notes && (
          <div>
            <Label className="text-sm font-medium mb-1 block">Notes</Label>
            <p className="text-sm">{report.notes}</p>
          </div>
        )}

        {report.rejectionReason && (
          <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-900">
            <Label className="text-sm font-medium text-red-600 dark:text-red-400 mb-1 block">Rejection Reason</Label>
            <p className="text-sm text-red-700 dark:text-red-300">{report.rejectionReason}</p>
          </div>
        )}
      </div>

      <div className="pt-4 border-t mt-4 space-y-2">
        {canSubmit && (
          <Button 
            className="w-full"
            onClick={onSubmit}
            disabled={isSubmitting}
          >
            <Send className="h-4 w-4 mr-2" />
            {isSubmitting ? "Submitting..." : "Submit for Approval"}
          </Button>
        )}
        <Button variant="outline" className="w-full" onClick={onClose}>
          Close
        </Button>
      </div>
    </div>
  );
}

function ReportApprovalSheet({
  report,
  onClose,
  onApprove,
  onReject,
  isApproving,
  isRejecting,
  rejectionReason,
  setRejectionReason,
}: {
  report: WeeklyJobReport;
  onClose: () => void;
  onApprove: () => void;
  onReject: () => void;
  isApproving: boolean;
  isRejecting: boolean;
  rejectionReason: string;
  setRejectionReason: (v: string) => void;
}) {
  const formatDateFull = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), "dd MMM yyyy");
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <SheetHeader className="pb-4">
        <SheetTitle className="text-left">Review Report</SheetTitle>
        <p className="text-sm text-muted-foreground text-left">
          Submitted by {report.projectManager?.name || report.projectManager?.email}
        </p>
      </SheetHeader>

      <div className="flex-1 overflow-auto space-y-4">
        <div className="p-3 bg-muted/50 rounded-lg">
          <p className="text-sm">
            <Calendar className="h-4 w-4 inline mr-2" />
            {formatDateFull(report.weekStartDate)} - {formatDateFull(report.weekEndDate)}
          </p>
        </div>

        {report.schedules && report.schedules.length > 0 && (
          <div>
            <Label className="text-sm font-medium mb-2 block">
              Jobs ({report.schedules.length})
            </Label>
            <div className="space-y-2">
              {report.schedules.map((schedule) => (
                <div key={schedule.id} className="p-3 bg-card border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-sm">
                      {schedule.job?.jobNumber} - {schedule.job?.name || "Unknown Job"}
                    </h4>
                    <Badge variant="outline" className="text-xs">
                      {schedule.scheduleStatus?.replace("_", " ")}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                    {schedule.levels7Days && <p>7 Day: {schedule.levels7Days}</p>}
                    {schedule.levels14Days && <p>14 Day: {schedule.levels14Days}</p>}
                    {schedule.levels21Days && <p>21 Day: {schedule.levels21Days}</p>}
                    {schedule.levels28Days && <p>28 Day: {schedule.levels28Days}</p>}
                  </div>
                  {schedule.siteProgress && (
                    <p className="text-xs text-muted-foreground mt-2">{schedule.siteProgress}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {report.notes && (
          <div>
            <Label className="text-sm font-medium mb-1 block">Notes</Label>
            <p className="text-sm">{report.notes}</p>
          </div>
        )}

        <div>
          <Label className="text-sm font-medium mb-1 block">Rejection Reason (if rejecting)</Label>
          <Textarea
            placeholder="Enter reason for rejection..."
            value={rejectionReason}
            onChange={(e) => setRejectionReason(e.target.value)}
            className="min-h-[60px]"
          />
        </div>
      </div>

      <div className="pt-4 border-t mt-4 space-y-2">
        <div className="flex gap-2">
          <Button 
            className="flex-1 bg-green-600 hover:bg-green-700"
            onClick={onApprove}
            disabled={isApproving || isRejecting}
          >
            <Check className="h-4 w-4 mr-2" />
            {isApproving ? "Approving..." : "Approve"}
          </Button>
          <Button 
            variant="destructive"
            className="flex-1"
            onClick={onReject}
            disabled={isApproving || isRejecting || !rejectionReason.trim()}
          >
            <X className="h-4 w-4 mr-2" />
            {isRejecting ? "Rejecting..." : "Reject"}
          </Button>
        </div>
        <Button variant="outline" className="w-full" onClick={onClose}>
          Close
        </Button>
      </div>
    </div>
  );
}
