/**
 * MYOB API Backend Server
 * Express server that connects to the MYOB Business API.
 */

import "dotenv/config";
import express from "express";
import cors from "cors";
import { router } from "./routes.js";

const app = express();
const PORT = process.env.PORT ?? 3000;

// DEBUG: Log every incoming request (remove after troubleshooting)
app.use((req, _res, next) => {
  console.log(`[DEBUG] Incoming: ${req.method} ${req.path} | Full URL: ${req.originalUrl}`);
  next();
});

app.use(cors());
app.use(express.json());

app.use("/api/myob", router);

app.get("/health", (_req, res) => {
  res.json({ status: "ok", service: "myob-api-backend" });
});

app.listen(PORT, () => {
  console.log(`MYOB API backend running at http://localhost:${PORT}`);
  console.log(`OAuth: GET http://localhost:${PORT}/api/myob/auth`);
  console.log(`Ensure MYOB_REDIRECT_URI is set to: http://localhost:${PORT}/api/myob/callback`);
});
