/**
 * Express routes that call the MYOB API.
 * This is the main entry point for your backend to fetch MYOB data.
 */

import { Router, Request, Response } from "express";
import {
  getAuthorizationUrl,
  exchangeCodeForToken,
  myob,
} from "./myob.js";

export const router = Router();

/**
 * OAuth: Redirect user to MYOB login
 * GET /api/myob/auth
 */
router.get("/auth", (_req: Request, res: Response) => {
  // DEBUG: Log OAuth credentials being used (remove after troubleshooting)
  console.log("[DEBUG] MYOB_CLIENT_ID:", process.env.MYOB_CLIENT_ID ?? "(empty)");
  console.log("[DEBUG] MYOB_REDIRECT_URI:", process.env.MYOB_REDIRECT_URI ?? "(empty)");

  const scope = "sme-company-file sme-company-settings sme-sales sme-contacts-customer";
  const authUrl = getAuthorizationUrl(scope);
  res.redirect(authUrl);
});

/**
 * OAuth callback: Exchange code for access token
 * MYOB redirects here with ?code=...&businessId=... (per auth docs)
 * We extract the code from the callback URL and exchange it for access_token + refresh_token
 */
router.get("/callback", async (req: Request, res: Response) => {
  // DEBUG: First line - confirms the callback route was hit
  console.log("[DEBUG] ========== CALLBACK ROUTE ENTERED ==========");

  // Explicitly extract code and businessId from the callback URL
  const baseUrl = `${req.protocol}://${req.get("host") || "localhost"}`;
  const url = new URL(req.originalUrl, baseUrl);
  const code = url.searchParams.get("code");
  const businessId = url.searchParams.get("businessId");

  // DEBUG: Log extracted params from redirect URL
  console.log("[DEBUG] Callback - raw URL:", req.originalUrl);
  console.log("[DEBUG] Extracted code:", code ? `${code.slice(0, 30)}...` : "(missing)");
  console.log("[DEBUG] Extracted businessId:", businessId ?? "(missing)");

  // Helper to send HTML response (visible in browser)
  const sendHtml = (title: string, message: string, isError = false) => {
    res.setHeader("Content-Type", "text/html");
    res.status(isError ? 400 : 200).send(
      `<!DOCTYPE html><html><head><title>${title}</title></head><body><h1>${title}</h1><p>${message}</p></body></html>`
    );
  };

  if (!code || !businessId) {
    console.log("[DEBUG] Callback FAILED - missing code or businessId");
    sendHtml("OAuth Error", "Missing code or businessId in callback. Check that MYOB redirects with both parameters.", true);
    return;
  }

  try {
    console.log("[DEBUG] Calling exchangeCodeForToken...");
    const tokenResponse = await exchangeCodeForToken(code, businessId);
    console.log("[DEBUG] Token exchange SUCCESS - access_token received");
    sendHtml(
      "OAuth Success",
      "OAuth complete. You can now call MYOB endpoints. Tokens have been stored."
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[DEBUG] Token exchange FAILED:", message);
    sendHtml("Token Exchange Failed", `Error: ${message}`, true);
  }
});

/**
 * Company info
 * GET /api/myob/company
 */
router.get("/company", async (_req: Request, res: Response) => {
  try {
    const data = await myob.getCompany();
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});

/**
 * Customers
 * GET /api/myob/customers
 */
router.get("/customers", async (req: Request, res: Response) => {
  try {
    const query = req.query.$filter ? `$filter=${req.query.$filter}` : undefined;
    const data = await myob.getCustomers(query);
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});

/**
 * Suppliers
 * GET /api/myob/suppliers
 */
router.get("/suppliers", async (req: Request, res: Response) => {
  try {
    const query = req.query.$filter ? `$filter=${req.query.$filter}` : undefined;
    const data = await myob.getSuppliers(query);
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});

/**
 * Chart of accounts
 * GET /api/myob/accounts
 */
router.get("/accounts", async (req: Request, res: Response) => {
  try {
    const query = req.query.$filter ? `$filter=${req.query.$filter}` : undefined;
    const data = await myob.getAccounts(query);
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});

/**
 * Invoices
 * GET /api/myob/invoices
 */
router.get("/invoices", async (req: Request, res: Response) => {
  try {
    const query = req.query.$filter ? `$filter=${req.query.$filter}` : undefined;
    const data = await myob.getInvoices(query);
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});

/**
 * Inventory items
 * GET /api/myob/items
 */
router.get("/items", async (req: Request, res: Response) => {
  try {
    const query = req.query.$filter ? `$filter=${req.query.$filter}` : undefined;
    const data = await myob.getItems(query);
    res.json(data);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    res.status(500).json({ error: "MYOB request failed", details: message });
  }
});
