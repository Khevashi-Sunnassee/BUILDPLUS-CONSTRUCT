/**
 * MYOB Business API Client
 * Handles OAuth 2.0 flow and API requests.
 * @see https://developer.myob.com/api/myob-business-api/api-overview/authentication/
 */

const MYOB_AUTH_URL = "https://secure.myob.com/oauth2/account/authorize";
const MYOB_TOKEN_URL = "https://secure.myob.com/oauth2/v1/authorize";
const MYOB_API_BASE = "https://api.myob.com/accountright";

export interface MyobTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: string;
  refresh_token: string;
  scope?: string;
  user?: { uid: string; username: string };
}

export interface MyobConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  cfUsername: string;
  cfPassword: string;
}

// In-memory token store (replace with DB/Redis in production)
let tokenStore: {
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: number;
  businessId?: string;
} = {};

/**
 * Get the OAuth authorization URL to redirect users to
 */
export function getAuthorizationUrl(scope: string = "sme-company-file"): string {
  const params = new URLSearchParams({
    client_id: process.env.MYOB_CLIENT_ID ?? "",
    redirect_uri: process.env.MYOB_REDIRECT_URI ?? "",
    response_type: "code",
    scope,
    prompt: "consent",
  });
  return `${MYOB_AUTH_URL}?${params.toString()}`;
}

/**
 * Exchange authorization code for access token
 */
export async function exchangeCodeForToken(
  code: string,
  businessId: string
): Promise<MyobTokenResponse> {
  const body = new URLSearchParams({
    client_id: process.env.MYOB_CLIENT_ID ?? "",
    client_secret: process.env.MYOB_CLIENT_SECRET ?? "",
    scope: "sme-company-file sme-company-settings sme-sales sme-contacts-customer",
    code,
    redirect_uri: process.env.MYOB_REDIRECT_URI ?? "",
    grant_type: "authorization_code",
  });

  const res = await fetch(MYOB_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Token exchange failed: ${res.status} ${err}`);
  }

  const data = (await res.json()) as MyobTokenResponse;
  const expiresIn = parseInt(data.expires_in, 10) || 1200;

  tokenStore = {
    accessToken: data.access_token,
    refreshToken: data.refresh_token,
    expiresAt: Date.now() + expiresIn * 1000,
    businessId,
  };

  return data;
}

/**
 * Refresh the access token using refresh_token
 */
export async function refreshAccessToken(): Promise<string> {
  if (!tokenStore.refreshToken) {
    throw new Error("No refresh token available. Complete OAuth flow first.");
  }

  const body = new URLSearchParams({
    client_id: process.env.MYOB_CLIENT_ID ?? "",
    client_secret: process.env.MYOB_CLIENT_SECRET ?? "",
    refresh_token: tokenStore.refreshToken,
    grant_type: "refresh_token",
  });

  const res = await fetch(MYOB_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Token refresh failed: ${res.status} ${err}`);
  }

  const data = (await res.json()) as MyobTokenResponse;
  const expiresIn = parseInt(data.expires_in, 10) || 1200;

  tokenStore.accessToken = data.access_token;
  tokenStore.refreshToken = data.refresh_token ?? tokenStore.refreshToken;
  tokenStore.expiresAt = Date.now() + expiresIn * 1000;

  return data.access_token;
}

/**
 * Get a valid access token (refresh if expired)
 */
export async function getValidAccessToken(): Promise<string> {
  const bufferSeconds = 60;
  if (
    tokenStore.accessToken &&
    tokenStore.expiresAt &&
    tokenStore.expiresAt > Date.now() + bufferSeconds * 1000
  ) {
    return tokenStore.accessToken;
  }
  return refreshAccessToken();
}

/**
 * Base64 encode credentials for x-myobapi-cftoken header
 */
function encodeCfToken(username: string, password: string): string {
  return Buffer.from(`${username}:${password}`, "utf-8").toString("base64");
}

/**
 * Make an authenticated request to the MYOB API
 */
export async function myobFetch<T = unknown>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const accessToken = await getValidAccessToken();
  const businessId = tokenStore.businessId;

  if (!businessId) {
    throw new Error(
      "No business ID. Complete OAuth flow first (visit /api/myob/auth)."
    );
  }

  const cfToken = encodeCfToken(
    process.env.MYOB_CF_USERNAME ?? "",
    process.env.MYOB_CF_PASSWORD ?? ""
  );

  const url = endpoint.startsWith("http")
    ? endpoint
    : `${MYOB_API_BASE}/${businessId}/${endpoint.replace(/^\//, "")}`;

  const method = (options.method ?? "GET").toUpperCase();
  console.log("[MYOB API] REQUEST:", method, url);

  const res = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "x-myobapi-cftoken": cfToken,
      "x-myobapi-key": process.env.MYOB_API_KEY ?? "",
      "x-myobapi-version": "v2",
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  const text = await res.text();

  // Log response (truncate large bodies)
  const preview = text.length > 500 ? `${text.slice(0, 500)}... [truncated, total ${text.length} chars]` : text;
  console.log("[MYOB API] RESPONSE:", res.status, res.statusText, "| Body preview:", preview || "(empty)");

  if (!res.ok) {
    throw new Error(`MYOB API error ${res.status}: ${text}`);
  }

  return (text ? JSON.parse(text) : {}) as T;
}

/**
 * Convenience methods for common endpoints
 */
export const myob = {
  /** GET /Company/ - Company info */
  getCompany: () => myobFetch("Company/"),

  /** GET /Contact/Customer/ - List customers */
  getCustomers: (query?: string) =>
    myobFetch(`Contact/Customer/${query ? `?${query}` : ""}`),

  /** GET /Contact/Supplier/ - List suppliers */
  getSuppliers: (query?: string) =>
    myobFetch(`Contact/Supplier/${query ? `?${query}` : ""}`),

  /** GET /GeneralLedger/Account/ - Chart of accounts */
  getAccounts: (query?: string) =>
    myobFetch(`GeneralLedger/Account/${query ? `?${query}` : ""}`),

  /** GET /Sale/Invoice/ - List invoices */
  getInvoices: (query?: string) =>
    myobFetch(`Sale/Invoice/${query ? `?${query}` : ""}`),

  /** GET /Inventory/Item/ - List inventory items */
  getItems: (query?: string) =>
    myobFetch(`Inventory/Item/${query ? `?${query}` : ""}`),

  /** GET /CompanyFile/ - Company files list */
  getCompanyFiles: () => myobFetch("CompanyFile/"),
};
