# MYOB Business API Backend

Backend server to connect to the [MYOB Business API](https://developer.myob.com/api/myob-business-api/api-overview/authentication/) and fetch data from MYOB endpoints.

**Tech stack:** Express + TypeScript

---

## Handover: Copy-Paste to Your Project

1. Copy the `server/` folder into your project.
2. Copy `package.json` dependencies (or add them manually):
   - `express`, `cors`, `dotenv`
   - Dev: `tsx`, `typescript`, `@types/express`, `@types/cors`, `@types/node`
3. Create a `.env` file (use `.env.example` as template) and paste your credentials.
4. Start the server with `npm run dev` (or your preferred script).

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Configure credentials

Copy `.env.example` to `.env` and fill in your values:

```env
MYOB_CLIENT_ID=your_api_key_here
MYOB_CLIENT_SECRET=your_api_secret_here
MYOB_REDIRECT_URI=http://localhost:3000/api/myob/callback
MYOB_CF_USERNAME=your_company_file_username
MYOB_CF_PASSWORD=your_company_file_password
PORT=3000
```

| Variable | Description |
|----------|-------------|
| `MYOB_CLIENT_ID` | Client ID – used for OAuth (authorize URL, token exchange) |
| `MYOB_API_KEY` | API Key – used for `x-myobapi-key` header on API requests |
| `MYOB_CLIENT_SECRET` | Your API Secret |
| `MYOB_REDIRECT_URI` | Must match the Redirect URL registered in your MYOB app |
| `MYOB_CF_USERNAME` | Company file username |
| `MYOB_CF_PASSWORD` | Company file password |

### 3. Run the server

```bash
npm run dev
```

---

## OAuth Flow (required for online company files)

1. Visit: `http://localhost:3000/api/myob/auth`
2. Log in to MYOB and authorize the app.
3. You are redirected to `/api/myob/callback` with `code` and `businessId`. The server exchanges the code for tokens and stores them.
4. After that, all MYOB endpoints work until the token expires (auto-refresh is handled).

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/myob/auth` | Start OAuth (redirects to MYOB) |
| GET | `/api/myob/callback` | OAuth callback (receives code & businessId) |
| GET | `/api/myob/company` | Company info |
| GET | `/api/myob/customers` | List customers |
| GET | `/api/myob/suppliers` | List suppliers |
| GET | `/api/myob/accounts` | Chart of accounts |
| GET | `/api/myob/invoices` | List invoices |
| GET | `/api/myob/items` | Inventory items |

---

## Project Structure

```
server/
  index.ts    # Express app & server entry
  routes.ts   # Main routes that call the MYOB API
  myob.ts     # Dedicated MYOB API client (auth, tokens, fetch)
```

---

## Adding More Endpoints

To fetch from other MYOB endpoints, add methods in `server/myob.ts` and corresponding routes in `server/routes.ts`. Example:

```ts
// myob.ts
getJobs: (query?: string) => myobFetch(`GeneralLedger/Job/${query ? `?${query}` : ""}`),

// routes.ts
router.get("/jobs", async (req, res) => {
  const data = await myob.getJobs(req.query.$filter ? `$filter=${req.query.$filter}` : undefined);
  res.json(data);
});
```

---

## Notes

- Tokens are stored in memory; for production, persist them in a database or Redis.
- Ensure your MYOB app’s Redirect URL matches `MYOB_REDIRECT_URI` exactly.
- For more endpoints and scopes, see [MYOB API docs](https://developer.myob.com/api/myob-business-api/v2/).
