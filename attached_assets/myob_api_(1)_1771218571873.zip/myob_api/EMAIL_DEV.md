Hi Kesh and Colin,
 
No worries, thanks for that. I have added kesh@optimisedsystems.com.au to the developer account LTE STRUCTURES - Developer Account (11261187). Please sign in to my.myob.com.au and select the account number 11261187 from the drop-down menu in the top right-hand corner, and you should be able to see the developer tab. From there you can register your API keys. Please see below for more information:
 
How do I register my application for an API Key
https://apisupport.myob.com/hc/en-us/articles/360000479916
 
MYOB OAuth2.0 Authentication Guide (Post-March 2025)
https://apisupport.myob.com/hc/en-us/articles/13065472856719
 
MYOB API Support: Granular Data Scopes
https://developer.myob.com/api/myob-business-api/api-overview/granular_data_scopes/
 
MYOB API Support: Scopes
https://developer.myob.com/api/myob-business-api/api-overview/scopes/
 
MYOB OAuth2.0 Scope Changes
https://apisupport.myob.com/hc/en-us/articles/13052819398415
 
Retrieving Company File GUIDs via MYOB API
https://apisupport.myob.com/hc/en-us/articles/12861196770447
 
OAuth2.0 Authentication Now Requires Admin Access
https://apisupport.myob.com/hc/en-us/articles/13052864214671
Stay in the know! Subscribe now to get API and product
updates, events information and the latest MYOB news.

Thanks

Stuart Woolford

API Integration Analyst

MYOB
Developer Centre - http://developer.myob.com/

MYOB API Support Centre -https://apisupport.myob.com/

MYOB - https://www.myob.com/